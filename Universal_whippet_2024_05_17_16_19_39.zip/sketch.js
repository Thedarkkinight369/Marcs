function setup() {
  createCanvas(570, 490);
background("black");
}

function draw(){    
fill("purple")
stroke("yellow");

if("mouseISpressed")
  {rect(mouseX, mouseY, 20,35);
}
}